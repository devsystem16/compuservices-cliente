self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "bb51845662ce7e20761ee749192f5103",
    "url": "/index.html"
  },
  {
    "revision": "07cb73ebacd4624b612b",
    "url": "/static/css/2.2b64612d.chunk.css"
  },
  {
    "revision": "4c61522813160352edf6",
    "url": "/static/css/main.ab261dff.chunk.css"
  },
  {
    "revision": "07cb73ebacd4624b612b",
    "url": "/static/js/2.f7c26449.chunk.js"
  },
  {
    "revision": "4c61522813160352edf6",
    "url": "/static/js/main.ab3edefd.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9e6cd5bd86cedcb6f3ae2cae59b466b8",
    "url": "public/static/media/logoCompuservices.9e6cd5bd.PNG"
  }
]);