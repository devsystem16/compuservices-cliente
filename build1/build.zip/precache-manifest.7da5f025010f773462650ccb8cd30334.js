self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "49d49d3eb258784028e3982e975f242c",
    "url": "/index.html"
  },
  {
    "revision": "a932e1efacf54b6a90b8",
    "url": "/static/css/2.2b64612d.chunk.css"
  },
  {
    "revision": "99f50865f00ef4d0476c",
    "url": "/static/css/main.bc0fe56a.chunk.css"
  },
  {
    "revision": "a932e1efacf54b6a90b8",
    "url": "/static/js/2.8c62c88d.chunk.js"
  },
  {
    "revision": "99f50865f00ef4d0476c",
    "url": "/static/js/main.d7d83cfc.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9e6cd5bd86cedcb6f3ae2cae59b466b8",
    "url": "public//static/media/logoCompuservices.9e6cd5bd.PNG"
  }
]);