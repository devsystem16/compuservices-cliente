self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "df749d83cf282efc4be4243839824197",
    "url": "/index.html"
  },
  {
    "revision": "07cb73ebacd4624b612b",
    "url": "/static/css/2.2b64612d.chunk.css"
  },
  {
    "revision": "1f5838a06b819d77e609",
    "url": "/static/css/main.bc0fe56a.chunk.css"
  },
  {
    "revision": "07cb73ebacd4624b612b",
    "url": "/static/js/2.f7c26449.chunk.js"
  },
  {
    "revision": "1f5838a06b819d77e609",
    "url": "/static/js/main.b5995b1d.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9e6cd5bd86cedcb6f3ae2cae59b466b8",
    "url": "public/static/media/logoCompuservices.9e6cd5bd.PNG"
  }
]);