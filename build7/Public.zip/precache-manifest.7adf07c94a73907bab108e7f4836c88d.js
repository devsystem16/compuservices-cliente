self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "46f6b2e4b501ffb8fea25387df8ca09f",
    "url": "/index.html"
  },
  {
    "revision": "392eb4e2773f5bde62da",
    "url": "/static/css/2.2b64612d.chunk.css"
  },
  {
    "revision": "c9172682e9105fca7914",
    "url": "/static/css/main.ab261dff.chunk.css"
  },
  {
    "revision": "392eb4e2773f5bde62da",
    "url": "/static/js/2.e667060b.chunk.js"
  },
  {
    "revision": "c9172682e9105fca7914",
    "url": "/static/js/main.e0c5cb82.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9e6cd5bd86cedcb6f3ae2cae59b466b8",
    "url": "public/static/media/logoCompuservices.9e6cd5bd.PNG"
  }
]);