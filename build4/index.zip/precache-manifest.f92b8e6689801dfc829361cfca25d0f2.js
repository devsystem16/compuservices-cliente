self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c1d0e4649ee80544047b8c8a46a4c5b0",
    "url": "/index.html"
  },
  {
    "revision": "07cb73ebacd4624b612b",
    "url": "/static/css/2.2b64612d.chunk.css"
  },
  {
    "revision": "db8a2dc4624568f061d9",
    "url": "/static/css/main.bc0fe56a.chunk.css"
  },
  {
    "revision": "07cb73ebacd4624b612b",
    "url": "/static/js/2.f7c26449.chunk.js"
  },
  {
    "revision": "db8a2dc4624568f061d9",
    "url": "/static/js/main.ee9bf049.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "9e6cd5bd86cedcb6f3ae2cae59b466b8",
    "url": "public/static/media/logoCompuservices.9e6cd5bd.PNG"
  }
]);